# Todoer — the competitive to-do list

A to-do list for the day, the week, and the month — except now it's a game.
Everyone playing creates an account, adds tasks to their own daily/weekly/monthly
lists, and earns points for finishing them. When a day, week, or month ends, the
top scorer for that period is automatically crowned and wins a random prize from
a pool of 20 real-life rewards.

## Stack

Plain PHP 8+ (no framework), SQLite (via PDO), HTML/CSS/vanilla JS. No build step,
no dependencies to install.

## How to run it

You need PHP with the `pdo_sqlite` extension (bundled with PHP on most systems).

```
cd todoer
php -S 0.0.0.0:8080
```

Then open `http://localhost:8080/login.php` in a browser. Using `0.0.0.0` instead
of `127.0.0.1` lets other players on the same Wi-Fi/LAN open
`http://<your-computer's-IP>:8080/login.php` on their own phone or laptop and
join with their own account — that's the "join 2+ persons" part.

On first run it creates `data/todoer.sqlite` automatically and seeds the 20-prize
pool. Nothing else to configure.

To run it permanently in the background instead of a one-off terminal window,
put it behind any standard PHP web server (Apache/Nginx + php-fpm) pointed at
this folder — no code changes needed.

## How the game works

- Each player has their own Daily, Weekly, and Monthly lists. Add a task, check
  it off when it's done.
- Points are flat by list: Daily = 1pt, Weekly = 3pts, Monthly = 5pts.
- The moment a day/week/month has fully elapsed, the app tallies everyone's
  points for that period, crowns whoever scored highest (ties are broken
  randomly), and awards them a random, not-yet-used prize from the pool. This
  check runs automatically whenever anyone loads a page — no cron job needed.
- The "Prizes" page shows the full history of who won what and when. A winner
  can mark their own prize as "claimed" once it's been redeemed in real life.
- The sidebar leaderboard shows Today / This week / This month / All-time
  standings side by side.

## The prize pool

Edit the list in `includes/db.php` (inside the `todoer_db()` seeding block) to
change the 20 prizes — things like "1 hour of uninterrupted rest", "a 20-minute
massage from the runner-up", "pick the next movie night", "skip a chore", etc.
Edits there only affect brand-new installs (a fresh `data/todoer.sqlite`); to
change the pool on an existing install, edit the `prizes` table directly, e.g.
with a one-off `php -r` script using PDO.

## Project layout

```
todoer/
  index.php            dashboard: lists + leaderboard
  login.php            sign in / join
  prizes.php           prize history + claim button
  logout.php
  includes/
    schema.sql         SQLite schema
    db.php             DB bootstrap + prize seeding
    auth.php           register/login/session helpers
    period.php         period keys, auto-close + prize award logic, leaderboards
    api_helpers.php     JSON request/response helpers
    bootstrap.php       wires the above together, runs the period auto-close
  api/
    tasks.php           list/add/complete/reopen/delete tasks (JSON)
    leaderboard.php      leaderboard data (JSON)
    prizes.php           prize history + claim (JSON)
  assets/
    css/style.css
    js/app.js            dashboard behaviour
    js/prizes.js          prizes page behaviour
  data/
    todoer.sqlite         created automatically on first run
```

## Notes / things you might want to change later

- Passwords are hashed with PHP's `password_hash` — fine for a household app,
  not audited for anything more sensitive than that.
- Task lists are private per player; only totals are visible to others, which
  keeps the competitive framing without turning it into surveillance.
- Ties for a period split the prize randomly between the tied top scorers
  rather than awarding it to both — easy to change in
  `todoer_close_one_period()` in `includes/period.php` if you'd rather award
  every tied winner.
